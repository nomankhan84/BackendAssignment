<?php
// src/Controller/TwitterAuthController.php
namespace App\Controller;

use App\Service\TwitterOAuthService;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class TwitterAuthController extends AbstractController
{
    #[Route('/auth/twitter', name: 'auth_twitter')]
    public function redirectToTwitter(TwitterOAuthService $twitterOAuthService): RedirectResponse
    {
        $authUrl = $twitterOAuthService->getAuthorizationUrl();
        return new RedirectResponse($authUrl);
    }

    #[Route('/auth/twitter/callback', name: 'auth_twitter_callback')]
    public function handleTwitterCallback(
        Request $request,
        TwitterOAuthService $twitterOAuthService,
        EntityManagerInterface $entityManager
    ): RedirectResponse {
        $oauthToken = $request->query->get('oauth_token');
        $oauthVerifier = $request->query->get('oauth_verifier');

        if (!$oauthToken || !$oauthVerifier) {
            return $this->redirectToRoute('auth_twitter');
        }

        $userData = $twitterOAuthService->getUserData($oauthToken, $oauthVerifier);

        // Check if user exists
        $user = $entityManager->getRepository(User::class)->findOneBy(['twitterId' => $userData['id']]);

        if (!$user) {
            $user = new User();
            $user->setTwitterId($userData['id']);
            $user->setUsername($userData['name']);
            $user->setProfileImage($userData['avatar']);
            $entityManager->persist($user);
            $entityManager->flush();
        }

        return $this->redirect('your_mobile_app://auth_success?user_id=' . $user->getId());
    }
}

