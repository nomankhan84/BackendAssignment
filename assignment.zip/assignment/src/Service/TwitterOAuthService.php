<?php
// src/Service/TwitterOAuthService.php
namespace App\Service;

use League\OAuth1\Client\Server\Twitter;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class TwitterOAuthService
{
    private Twitter $server;
    private RequestStack $requestStack;

    public function __construct(UrlGeneratorInterface $router, RequestStack $requestStack)
    {
        $this->server = new Twitter([
            'identifier' => $_ENV['TWITTER_CLIENT_ID'],
            'secret' => $_ENV['TWITTER_CLIENT_SECRET'],
            'callback_uri' => $_ENV['TWITTER_CALLBACK_URL'],
        ]);
        $this->requestStack = $requestStack;
    }

    public function getAuthorizationUrl(): string
    {
        $temporaryCredentials = $this->server->getTemporaryCredentials();
        $this->requestStack->getSession()->set('oauth_token', $temporaryCredentials);
        return $this->server->getAuthorizationUrl($temporaryCredentials);
    }

    public function getUserData(string $oauthToken, string $oauthVerifier): array
    {
        $temporaryCredentials = $this->requestStack->getSession()->get('oauth_token');

        $tokenCredentials = $this->server->getTokenCredentials(
            $temporaryCredentials,
            $oauthToken,
            $oauthVerifier
        );

        $user = $this->server->getUserDetails($tokenCredentials);

        return [
            'id' => $user->uid,
            'name' => $user->nickname,
            'avatar' => $user->imageUrl,
        ];
    }
}

