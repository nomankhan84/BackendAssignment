'mysqldump' is not recognized as an internal or external command,
operable program or batch file.
